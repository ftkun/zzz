"/z" - main frame
"/zzzgg" - trade gold macro

"/target mouseover
/zzzgg" - simple mouseover gold trade macro